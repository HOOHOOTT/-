import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from collections import Counter
usecols = ['park_id','weather','time','holidays','location','capacity']
park = pd.read_csv('parking_records.csv', usecols=usecols,dtype={'park_at':int,'weather':int,'time':int,'holidays':int,'location':int,'capacity':int})