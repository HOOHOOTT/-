from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from collections import Counter
import pickle

app = Flask(__name__)

usecols = ['park_id','weather','time','holidays','location','capacity']
park = pd.read_csv('parking_records.csv', usecols=usecols,dtype={'park_at':int,'weather':int,'time':int,'holidays':int,'location':int,'capacity':int})
y_train= park ['park_id']
X_train= park [['location','time','holidays','weather']]

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

usecols = ['park_id','parking_space']
space_count = pd.read_csv('lstm.csv', usecols=usecols,dtype={'park_id':int,'parking_space':float})

def cpurpose(purpose):
    if purpose == 'work':
        purpose = 301
    elif purpose == 'community':
        purpose = 308
    elif purpose == 'park':
        purpose = 302
    elif purpose == 'hospital':
        purpose = 303
    elif purpose == 'restaurant':
        purpose = 306
    elif purpose == 'school':
        purpose = 304
    elif purpose == 'hotel':
        purpose = 305
    elif purpose == 'shopping':
        purpose = 307
    return purpose
def cweather(w):
    if w == 'sunny':
        w = 201
    elif w == 'rainy':
        w = 203
    elif w == 'cloudy':
        w = 202
    elif w == 'thunder':
        w = 204
    return w
def choliday(h):
    if h == 'ordinary':
        h = 111
    elif h == 'holiday':
        h = 10
    elif h == 'national':
        h = 11
    return h
def ctime(t):
    if t == 'zero':
        t = 10007
    elif t == 'seven':
        t = 10708
    elif t == 'eight':
        t = 10809
    elif t == 'nine':
        t = 10910
    elif t == 'ten':
        t = 11011
    elif t == 'eleven':
        t = 11112
    elif t == 'twelve':
        t = 11213
    elif t == 'thirteen':
        t = 11314
    elif t == 'forteen':
        t = 1415
    elif t == 'fifteen':
        t = 11516
    elif t == 'sixteen':
        t = 11617
    elif t == 'seventeen':
        t = 11718
    elif t == 'eighteen':
        t = 11819
    elif t == 'nineteen':
        t = 11920
    elif t == 'twenty':
        t = 12021
    elif t == 'twentyone':
        t = 12124
    return t

@app.route("/停車場推薦系統前端")
def test():
    return render_template('停車場推薦系統前端.html')
@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.get_json()
    purpose = data["purpose"]
    weather = data["weather"]
    holiday = data["holiday"]
    time = data["time"]
    purpose = cpurpose(purpose)
    weather = cweather(weather)
    holiday = choliday(holiday)
    time = ctime(time)
    input_array = [[purpose, time, holiday, weather]]
    testarray = [purpose, time, holiday, weather]
    distances, neighbors = knn.kneighbors(input_array, n_neighbors=100, return_distance=True)

    park_prediction = np.empty(100)
    a = 0
    for distance, neighbor in zip(distances[0], neighbors[0]):
        park_prediction[a] = y_train[neighbor]
        a += 1

    def get_count(elem):
        return arr.count(elem)

    arr = park_prediction.tolist()

    sorted_list = sorted(set(arr), key=get_count, reverse=True)

    park_prediction_three = (sorted_list[:3])

    # 讀取 LSTM 模型進行預測

    space_count = pd.read_csv('lstm.csv', usecols=['park_id', 'parking_space'], dtype={'park_id': int, 'parking_space': float})
    space_count.set_index('park_id', inplace=True)
    space_count = space_count.to_dict('dict')['parking_space']

    recommended_parking_lot = ""
    for i in park_prediction_three:
        if i in space_count:
            if space_count[i] > 20:
                availability = "多"
            elif space_count[i] > 10:
                availability = "中等"
            else:
                availability = "少"
            recommended_parking_lot += "Park ID: " + str(i) + " 剩餘車位數量: " + availability + "<br>"
    if recommended_parking_lot == "":
        recommended_parking_lot = "No parking lots available"

    return jsonify({"recommended_parking_lot": recommended_parking_lot})


    #recommended_parking_lot=back[0]
    #return back[0]
    #recommended_parking_lot=str(testarray[0])+"<br>"+str(testarray[1])+"<br>"+str(testarray[2])+"<br>"+str(testarray[3])
    # 回傳 JSON 格式的推薦結果
    #return jsonify({"recommended_parking_lot":recommended_parking_lot})
   # return jsonify(park_prediction_three)

if __name__ == "__main__":
    app.run(debug=True)